### Initial Setup
* `bower install && npm install`

### Development
* `gulp serve`