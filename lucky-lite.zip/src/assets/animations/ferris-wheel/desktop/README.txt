This archive contains a template for hosting your Goo Create project on a web server.
Look in index.html for some guidance on how to do this.