This is the whole content of your Goo Create project, the bundle file can be loaded
into an other project using our engine, Goo Engine.

Example of engine usage can be found in the webpage download.

Class in the engine for loading:
http://code.gooengine.com/latest/docs/DynamicLoader.html

Tutorials:
http://www.goocreate.com/learn/tutorials/