(function() {
  'use strict';

  angular.module('finnplay.models.withdrawal', [
  ])

  .service('Withdrawal', function($q, $ajax){
    var model = this,
        prefillingFormFields,
        details;

    var URLS = {
      initPrefill: '/billfold-api/payment/initPrefillWithdrawal',
      updatePrefill: '/billfold-api/payment/prefillWithdrawal',
      validateAddress: '/billfold-api/player/validateAddress',
      details: '/billfold-api/payment/initWithdraw',
      withdraw: '/billfold-api/payment/withdraw',
      cancel: '/billfold-api/payment/cancelWithdraw' 
    };

    /**
     * Withdrawal Prefill
     */

    model.getPrefillingFormFields = function (update) {
      if (!update && prefillingFormFields) {
        return $q.when(prefillingFormFields);
      }

      return $ajax({
        method: 'GET',
        url: URLS.initPrefill,
        cache: !update,
        filter: function (response) {
          prefillingFormFields = {};
          if (!response.hasOwnProperty('error')) {
            prefillingFormFields = response;
          }
          return prefillingFormFields;
        }
      });
    };

    // POST: <user details> ...
    model.updatePrefillingData = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.updatePrefill,
        data: params
      }).then(function (response) {
        if (response.hasOwnProperty('success')) {
          return model.getDetails(true).then(function () {
            return response;
          });
        }
        return response;
      });
    };

    // POST: <user details> ...
    model.checkPrefillingData = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.validateAddress,
        data: params
      });
    };

    /**
     * Withdrawal
     */

    model.getDetails = function (update) {
      if (!update && details) {
        return $q.when(details);
      }

      return $ajax({
        method: 'GET',
        url: URLS.details,
        cache: !update
      }).then(function (response) {
        details = response;
        return details;
      });
    };

    // POST: amount, method, <user details> ...
    model.withdraw = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.withdraw,
        data: params        
      }).then(function (response) {
        if (response.hasOwnProperty('success')) {
          return model.getDetails(true).then(function () {
            return response;
          });
        }
        return response;
      });
    };

    // POST: reference
    model.cancel = function (reference) {
      return $ajax({
        method: 'POST',
        url: URLS.cancel,
        data: {reference: reference}        
      });
    };

  });

})();