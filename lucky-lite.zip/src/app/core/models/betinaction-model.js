(function() {
  'use strict';

  // можно так:
  //   /billfold-api/game/{demo|real}/BIALiveMobile
  // или так
  // /billfold-api/game/{demo|real}/250012

  angular.module('finnplay.models.betinaction', [])
    .service('BetInAction', function ($q, $ajax, $filter, $rootScope, Fn, CacheFactory, Const, User) {
      var model = this;

      var URLs = {
        prelive: function () {
          return '/billfold-api/game/' + ($rootScope.isLoggedIn ? 'real' : 'demo') + '/' + (Fn.isMobile ? 'BIALiveMobile' : 'BIAPreLive') + '?t=' + (new Date()).getTime()
        }
      };

      model.getPreLive = function () {
        return $ajax({
          method: 'GET',
          url: URLs.prelive(),
          cache: false,
          filter: function (response) {

            return response;
          }
        });
      }
    });


})();
