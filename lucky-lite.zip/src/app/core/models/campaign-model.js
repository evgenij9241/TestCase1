(function() {
  'use strict';

  // FS-{fsRow number}-{fsColumn number}-{fsOrder in given game campaign}-{desktop game id}-{mobile game id} {Title}
  var FS_REGEXP = /^FS-(\d)-(\d)-(\d)-(\d+)-?(\d+)? (.*)$/i;

  // Unique marker on campaing title. F.e.: FS-1-1-1-52341 UQ Riding hood
  var UQ_REGEXP = /UQ (.*)$/i;

  // D-{dRow number}-{dOrder in given heap} {Title}
  var D_REGEXP = /^D-(\d)-(\d) (.*)$/i;

  // a-{desktop game id}-{mobile game id} {Title}
  var AFFILIATE_SIGNUP_REGEXP = /^a-(\d)-(\d) (.*)$/i;

  // affiliate - {number} {Title}
  var AFFILIATE_DEPOSIT_REGEXP = /^affiliate - (\d+) (.*)$/i;

  // title + subtitle
  var SUBTITLE_REGEXP = /^([^\+]*)\+(.*)$/;

  var MAXIMUM_DEPOSIT_BONUSES = 4; // maximum number of deposit campaigns for bonuses
  var MAXIMUM_BONUSES = 6; // maximum number of deposit + FS campaigns for bonuses

  angular.module('finnplay.models.campaign', [
  ])

  .service('Campaign', function($rootScope, $filter, Const, Currency){
    var model = this;
    var bonusDpCampaigns; // store deposit campaigns that can be shown on bonuses section
    var bonusFsCampaigns; // store FS campaigns that can be shown on bonuses section

    model.title = title;
    model.iconUrl = iconUrl;
    model.prepareAllCampaigns = prepareAllCampaigns;
    model.prepareBonusCampaigns = prepareBonusCampaigns;
    model.getBonuses = getBonuses;
    model.getSliderBonuses = getSliderBonuses;
    model.bonusAmount = bonusAmount;
    model.changeAmount = changeAmount;


    // Get campaign title
    function title (campaign) {
      if (!campaign.fs) { return campaign.title; }
      var replacements = {
        // amount: campaign.bonusAmount,
        name: campaign.title
      };
      return $filter('translate')('APP.FIELD.FREESPINS_SHOP.SHORT_LABEL', replacements);
    }

    // Get url of game icon for FS campaign
    function iconUrl (campaign) {
      if (!campaign.fs) { return null; }

      return Const.ENV.assets + '/images/games-logos/logo-' + campaign.desktopGameId + '.png';
    }

    // Get bonusAmount by campaign object
    function bonusAmount(campaign) {
      return campaign.promoAmount || campaign.cashAmount || campaign.freeSpinAmount || 0;
    }

    function multiCurrencyDepositCampaign (campaigns, currency) {
      if (!campaigns || !campaigns.length) return campaigns;

      return campaigns.map(function (campaign) {
        if (campaign.modified) return campaign;

        // Change max and min deposit amount for campaings without maxAmountCapEnabled only
        if (!campaign.maxAmountCapEnabled) {
          if (['SEK', 'NOK'].indexOf(currency) > -1) {
            campaign.minDepositAmount = campaign.minDepositAmount * Const.currencyDivider;
          } else {
            campaign.maxDepositAmount = campaign.maxDepositAmount / Const.currencyDivider;
          }
        }

        campaign.modified = true;

        return campaign;
      });
    }

    /*
      Get unprocessed list of all campagins and methods from backend
      Find max fees of all methods
      Prepare list of deposit campaigns, freeSpinShop campaigns
      And set amount and realAmount of each campaign by campaign.amount and max fee (fixed or percentage - what is max by given amount)

      @param campaigns: Array of unprocessed campaigns
      @param methods: Array of methods with their fees
      @param currency: code of currency (EUR, USD, SEK, etc.)

      @return Hash: { deposit: Array of campaigns, freeSpinsShop: Array of campaigns }
    */
    function prepareAllCampaigns(campaigns, methods, currency) {
      var result = { deposit: [], freeSpinsShop: [] };
      // var maxFees = getMaxFees(methods, currency);

      angular.forEach(campaigns, function(campaign){
        // initCampaignByTitle(campaign, currency, maxFees);
        initCampaignByTitle(campaign, currency);
      });
      // }

      //Multi-currency campaigns hack
      campaigns = multiCurrencyDepositCampaign(campaigns, currency);

      result.deposit = depositCampaigns(campaigns);

      result.freeSpinsShop = freeSpinsShopCampaigns(campaigns);

      prepareBonusCampaigns(result.deposit, result.freeSpinsShop);

      return result;
    }

    /*
      Returns list of campaigns for Free Spins Shop by list of all campaigns
      It's filtered by name first. Campaign name for FS Shop will look like:
      "FS-1-1-1-370191-370193 StarBurst"
      FS-{fsRow number}-{fsColumn number}-{fsOrder in given game campaign}-{desktop game id}-{mobile game id} {Title}

      "fsOrder in given game campaign" - it's a nubmer 1-4
      We will need to get just one of that 1-4 campaigns with this lowest fsOrder number
      F.e. if there is campaign with 1 - then we select this campaing and ignore 2, 3, 4
      if there is no campaign with 1, and 2, but with 3 and 4 - the we select 3 campaign and ignore 4.

      "fsRow number" and "fsColumn number" - it's for some kind of grid

      @param Array - list of all campaigns

      @return Array of Arrays
        index - sorted by "fsRow number" (1,2,3)
        value - Array of campaigns for that fsRow sorted by "fsColumn number"
    */
    function freeSpinsShopCampaigns (allCampaigns){
      var rows = {}, result = [];

      angular.forEach(allCampaigns, function(campaign){
        // campaign = initCampaignByTitle(campaign, currency);

        // Do not show campaign on mobile device if there is no mobileGameId for given campaign
        if (campaign.fs && !($rootScope.isMobile && !campaign.mobileGameId)) {
          if (!rows.hasOwnProperty(campaign.fsRow)) {
            rows[campaign.fsRow] = [];
          }

          // If there is already campaign on given "fsOrder in given game campaign"
          // and new campaign has lower fsOrder number
          // then replace old campaing on given fsOrder with new one
          var previousCampaingInOrder = rows[campaign.fsRow][campaign.fsColumn];
          if (!(previousCampaingInOrder && previousCampaingInOrder.fsOrder < campaign.fsOrder)) {
            rows[campaign.fsRow][campaign.fsColumn] = campaign;
          }
        }
      });

      var rowKeys = Object.keys(rows);
      for(var i=0, len=rowKeys.length; i < len; i++) {
        result.push(rows[rowKeys[i]].filter(function(campaign){ return !!campaign; }));
      }

      return result;
    }

    /*
      Returns list of campaigns for Deposit page (excluded FS campaigns) by list of all campaigns
      It's filtered by name first. Campaign name for Deposit will look like:
      "D-1-1 StarBurst"
      D-{dRow number}-{dOrder in given heap} {Title}

      "dOrder in given heap" - it's a nubmer 1-4
      We will need to get just one of that 1-4 campaigns with this lowest dOrder number
      F.e. if there is campaign with 1 - then we select this campaing and ignore 2, 3, 4
      if there is no campaign with 1, and 2, but with 3 and 4 - the we select 3 campaign and ignore 4.

      "dRow" - it's a sorting on our 'Bonuses' row

      @param Array - list of all campaigns

      @return Array of campaigns sorted by "dRow number" (1,2,3)
    */
    function depositCampaigns (allCampaigns){
      var rows = {}, result = [];

      angular.forEach(allCampaigns, function(campaign){
        // Do not show campaign on mobile device if there is no mobileGameId for given campaign
        if (!campaign.fs && campaign.hasOwnProperty('dOrder')) {
          // If there is already campaign on given dOrder
          // and new campaign has lower dOrder number
          // then replace old campaing on given dOrder with new one
          var previousCampaingInOrder = rows[campaign.dRow];
          if (!(previousCampaingInOrder && previousCampaingInOrder.dOrder < campaign.dOrder)) {
            rows[campaign.dRow] = campaign;
          }
        }

        if (campaign.promoCode) { rows[100] = campaign; } // if there is promoCode campaign - put it to the end of the list
      });

      var rowKeys = Object.keys(rows).sort();

      for(var i = 0, len = rowKeys.length; i < len; i++) {
        if (rows[rowKeys[i]].minDepositAmount) {
          result.push(rows[rowKeys[i]]);
        }
      }

      if (rows[100]) {
        result.push(rows[100])
      }

      return result;
    }

    /*
      Optimization to work with bonuses section on deposit page
      @param Array - list of deposit campaigns
      @param Array - list of FS campaigns
    */
    function prepareBonusCampaigns(dpCampaigns, fsCampaigns) {
      bonusDpCampaigns = [];
      bonusFsCampaigns = [];
      var campaign, i, k, len, klen;

      for (i = 0, len = dpCampaigns.length; i < len; i++) {
        campaign = dpCampaigns[i];
        if (campaign.hasOwnProperty('campaignId') && campaign.hasOwnProperty('minDepositAmount')) {
          bonusDpCampaigns.push(campaign);
        }
      }

      for (i = 0, len = fsCampaigns.length; i < len; i++) {
        var keys = Object.keys(fsCampaigns[i]);
        for (k = 0, klen = keys.length; k < klen; k++) {
          campaign = fsCampaigns[i][keys[k]];
          bonusFsCampaigns.push(campaign);
        }
      }
    }

    /*
      Get the list of Bonuses (for bonuses section on deposit page)
      concerning on the list of @campaigns by given minimal @amount

      @param Number - minimal amount
      @return Array - list of bonus campaigns
    */
    function getBonuses(amount) {
      var bonuses = [];
      var campaign, i, k, len, klen;
      var numberOfCampaigns = 0;

      // First step - select 1-4 deposit campaigns
      for (i = 0, len = bonusDpCampaigns.length; i < len; i++) {
        if (numberOfCampaigns < MAXIMUM_DEPOSIT_BONUSES) { // Select maximum 4 deposit campaigns
          campaign = bonusDpCampaigns[i];
          if (!campaign.fs && isCampaignHasEnoughAmount(campaign, amount)) {
            bonuses.push(campaign);
            numberOfCampaigns = numberOfCampaigns + 1;
          }
        }
      }

      // Second step - add few more FS campaigns and total number of campaigns must be MAXIMUM_BONUSES or less
      // We will run through all FS campaigns MAXIMUM_BONUSES - numberOfCampaigns times (mostly 2 times, because there will be 4 deposit campaigns for most cases)
      var selectedFsCampaigns = []; // store campaign id of already selected FS campaigns
      for (k = 0, klen = MAXIMUM_BONUSES - numberOfCampaigns; k < klen; k++) {
        if (numberOfCampaigns < MAXIMUM_BONUSES) {
          var fsCampaign = null;

          // Run through all fsCampaigns to find one campaign
          for (i = 0, len = bonusFsCampaigns.length; i < len; i++) {
            if (numberOfCampaigns < MAXIMUM_BONUSES) {
              campaign = bonusFsCampaigns[i];
              if (selectedFsCampaigns.indexOf(campaign.campaignId) === -1) { // skip already selected FS campaign
                if (isCampaignHasEnoughAmount(campaign, amount)) {
                  if (!fsCampaign) {
                    fsCampaign = campaign;
                  } else {
                    // If given campaign has more and enough minDepositAmout then previously found - then it will fit best our needs
                    if (fsCampaign.minDepositAmount < campaign.minDepositAmount) {
                      fsCampaign = campaign;
                    }
                  }
                }
              }
            }
          }

          // We select one FS campaign on each run
          if (fsCampaign) {
            bonuses.push(fsCampaign);
            numberOfCampaigns = numberOfCampaigns + 1;
            selectedFsCampaigns.push(fsCampaign.campaignId);

          // If there is not found FS campaign on this run - then there will be no campaign on any next run, then break
          } else {
            break;
          }
        }
      }

      return bonuses;
    }


    /*
      Get the list of Bonuses (for bonuses on deposit slider)
      concerning on the list of @campaigns by given minimal @amount

      There must be 1 D campaign and one FS campaign in normal case
      If no D campaign for given amount - return 2 FS campaigns

      @param Number - minimal amount
      @return Array - list of bonus campaigns
    */
    function getSliderBonuses(amount) {
      var bonuses = [];
      var campaign, i, k, len, klen;
      var numberOfCampaigns = 0;

      // First step - select 1 deposit campaign
      for (i = 0, len = bonusDpCampaigns.length; i < len; i++) {
        if (numberOfCampaigns < 1) { // Select one deposit campaign
          campaign = bonusDpCampaigns[i];
          if (!campaign.fs && isCampaignHasEnoughAmount(campaign, amount)) {
            bonuses.push(campaign);
            numberOfCampaigns = numberOfCampaigns + 1;
          }
        }
      }

      // Second step - add 1 or 2 fmore FS campaigns and total number of campaigns must be 2
      var selectedFsCampaigns = []; // store campaign id of already selected FS campaigns
      for (k = 0, klen = 2 - numberOfCampaigns; k < klen; k++) {
        if (numberOfCampaigns < 2) {
          var fsCampaign = null;

          // Run through all fsCampaigns to find one campaign
          for (i = 0, len = bonusFsCampaigns.length; i < len; i++) {
            if (numberOfCampaigns < 2) {
              campaign = bonusFsCampaigns[i];
              if (selectedFsCampaigns.indexOf(campaign.campaignId) === -1) { // skip already selected FS campaign
                if (isCampaignHasEnoughAmount(campaign, amount)) {
                  if (!fsCampaign) {
                    fsCampaign = campaign;
                  } else {
                    // If given campaign has more and enough minDepositAmout then previously found - then it will fit best our needs
                    if (fsCampaign.minDepositAmount < campaign.minDepositAmount) {
                      fsCampaign = campaign;
                    }
                  }
                }
              }
            }
          }

          // We select one FS campaign on each run
          if (fsCampaign) {
            bonuses.push(fsCampaign);
            numberOfCampaigns = numberOfCampaigns + 1;
            selectedFsCampaigns.push(fsCampaign.campaignId);

          // If there is not found FS campaign on this run - then there will be no campaign on any next run, then break
          } else {
            break;
          }
        }
      }

      return bonuses;
    }

    // Check if campaign has enough minAmount to be a bonus for given amount on deposit page
    function isCampaignHasEnoughAmount(campaign, amount) {
      return amount >= campaign.minDepositAmount &&
             (amount <= campaign.maxDepositAmount || campaign.maxAmountCapEnabled);
    }

    function changeAmount (amount, currency, multiply) {
      var multiplier = Const.currencyMultipliers[currency] || 1;

      if (!multiply) {
        multiplier = multiplier / Const.currencyDivider;
      }

      return amount * multiplier;
    }
    /* Private methods */



    // Parse campaign title and return campaign object with few params from it's title
    var initCampaignByTitle = function(campaign, currency, maxFees) {
      var match;
      if (!campaign.title) { return campaign; }

      match = campaign.title.match(FS_REGEXP);
      if (match) {
        // It's a FreeSpins Shop campaign
        campaign.fs = true;
        campaign.fsRow = parseInt(match[1]) - 1;
        campaign.fsColumn = parseInt(match[2]) - 1;
        campaign.fsOrder = parseInt(match[3]);
        campaign.desktopGameId = match[4];
        campaign.mobileGameId = match[5];

        //campaign.minDepositAmount = changeAmount(campaign.minDepositAmount, currency, true); // multiply kr minAmount by 10
        // campaign.realMinAmount = campaign.minDepositAmount;
        // campaign.minDepositAmount = amountWithFee(campaign.minDepositAmount, maxFees);

        campaign.title = match[6];
        var uniqueMatch = campaign.title.match(UQ_REGEXP);
        if (uniqueMatch) {
          campaign.title = uniqueMatch[1];
          campaign.unique = true;
        }
      }

      if (campaign.fs) { return campaign; }



      campaign.fs = false;

      match = campaign.title.match(D_REGEXP);
      if (match) {
        campaign.dRow = parseInt(match[1]);
        campaign.dOrder = parseInt(match[2]);
        campaign.title = match[3];
        var subtitleMatch = campaign.title.match(SUBTITLE_REGEXP);
        if (subtitleMatch) {
          campaign.title = subtitleMatch[1];
          campaign.subTitle = subtitleMatch[2];
          if (campaign.freeSpinAmount) {
            campaign.subTitle = '+' + campaign.freeSpinAmount + ' ' + campaign.subTitle;
          }
        }

        var uniqueMatch = campaign.title.match(UQ_REGEXP);
        if (uniqueMatch) {
          campaign.title = uniqueMatch[1];
          campaign.unique = true;
        }

        return campaign;
      }

      match = campaign.title.match(AFFILIATE_SIGNUP_REGEXP);
      if (match) {
        campaign.dRow = 0;
        campaign.dOrder = 1;
        campaign.title = match[3];
        return campaign;
      }

      match = campaign.title.match(AFFILIATE_DEPOSIT_REGEXP);
      if (match) {
        campaign.dRow = 0;
        campaign.dOrder = 1;
        campaign.title = match[2];
      }

      return campaign;
    };


    // Calculate max fixed fee and max percentage fee
    function getMaxFees(methods, currency) {
      var result = { fixed: 0, percentage: 0 };
      angular.forEach(methods, function(method){
        if (method.percentageFee && method.percentageFee > result.percentage) {
          result.percentage = method.percentageFee;
        }
        if (method.fee && method.fee[currency] && method.fee[currency] > result.fixed) {
          result.fixed = method.fee[currency];
        }
      });

      return result;
    }

    /*
      Calculate amount by given amount + maximum fee
      Calculate both:
      amount + fixed fee
      amount / (1 - percentage fee)
      Return max of it

      @param amount: Float - original amount of campaign from backend
      @param fee: Hash of fixed, percentage fee - look @getMaxFees method

      @return Float
    */
    function amountWithFee(amount, fee) {
      var fixed = parseFloat(amount + fee.fixed);
      var percentage = parseFloat(amount / (1 - fee.percentage/100));
      return (fixed > percentage) ? fixed : percentage;
    }

  });

})();
