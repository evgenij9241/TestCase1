(function() {
  'use strict';

  angular.module('finnplay.models.language', []).service('Language', function($q, $ajax, $stateParams, $translate, CacheFactory){
    var model = this,
        current,
        available,
        USER_LANGUAGE = 'userLanguage';

    var URLS = {
      current: '/billfold-api/player/language',
      change: '/billfold-api/player/changeLanguage',
      languages: '/billfold-api/config/languages'
    };

    var cache = new CacheFactory('language');

    model.get = function (update) {
      if (!update && current) {
        return $q.when(current);
      }

      return $ajax({
        method: 'GET',
        url: URLS.current,
        cache: !update,
        filter: function (response) {
          if (response.hasOwnProperty('error')) {
            response = { _lang: '' };
          }
          current = response._lang;
          return current;
        }
      });
    };

    // POST: "language"
    model.change = function (language) {
      return $ajax({
        method: 'POST',
        url: URLS.change,
        data: { language: language }
      }).then(function (response) {
        if (response.hasOwnProperty('success')) {
          current = language;
          $translate.use($stateParams.language = language);
          cache.put(USER_LANGUAGE, language);
        }
        return response;
      });
    };

    model.getLanguages = function (update) {
      if (!update && available) {
        return $q.when(available);
      }

      return $ajax({
        method: 'GET',
        url: URLS.languages,
        filter: function (response) {
          if (response.hasOwnProperty('error')) {
            response = { languages: [] };
          }
          available = response.languages;
          return angular.copy(available);
        }
      });
    };

    model.syncWithUrl = function (urlParams, update) {
      var params = urlParams || $stateParams || {};

      return model.get(update).then(function (apiLanguage) {
        var language = (params.language || cache.get(USER_LANGUAGE)) || apiLanguage;

        if (language !== apiLanguage) {
          return model.change(language).then(function (data) {
            if (data.hasOwnProperty('error')) {
              $translate.use(urlParams.language = $stateParams.language = apiLanguage);
              return apiLanguage;
            }
            return language;
          }, function () {
            $translate.use(urlParams.language = $stateParams.language = apiLanguage);
            return apiLanguage;
          });
        }
        if (!params.language) {
          $stateParams.language = language;
          if (urlParams) {
            urlParams.language = language;
          }
        }
        if (language !== $translate.use()) {
          $translate.use(language);
        }

        return language;
      }, function () {
        return params.language || '';
      });
    };

    model.clean = function () {
      current = null;
      $stateParams.language = null;
    };
  });

})();
