(function() {
  'use strict';

  angular.module('finnplay.models.user', []).service('User', function($q, $ajax, $translate, $rootScope, $http,
                                                                      $cookies, $timeout, CacheFactory, Fn, Const, fpModal, md5){
    var model = this,
      loggedIn = false,
      balance,
      wallet,
      details,
      myDetailsFormFields,
      country,
      jurisdictionsAccess,
      paymentDetails,
      freeSpins,
      freeSpinsCount,
      loyalty,
      loyaltyRate,
      withdrawalNeededTypes;

    var URLS = {
      details: '/billfold-api/player',
      close: '/billfold-api/player/close',
      coolOffDays: '/billfold-api/player/limit/coolOff',
      updateDetails: '/billfold-api/player/updateDetails',
      updateFields: '/billfold-api/player/updateFields',
      initDetails: '/billfold-api/player/initDetails',
      balance: '/billfold-api/player/balance',
      updatePassword: '/billfold-api/player/updatePassword',
      contactUs: '/billfold-api/contactus',
      duplicationCheck: '/billfold-api/player/:name',
      country: '/billfold-api/config/country',
      paymentDetails: '/billfold-api/player/paymentDetails',
      updatePaymentDetails: '/billfold-api/player/updatePaymentDetails',
      bonuses: '/billfold-api/player/bonuses/freeSpins',
      bonusCancel: '/billfold-api/player/bonuses/freeSpins/cancel',
      loyalty: '/billfold-api/player/loyalty',
      loyaltyRate: '/billfold-api/player/loyaltyRate',
      convertLoyalty: '/billfold-api/player/convertLoyaltyPoints',
      myAffiliate: '/billfold-api/player/myAffiliate',
      documents: '/billfold-api/player/documents',
      documentUpload: '/billfold-api/player/documentUpload',
      jurisdictionsAccess: '/data/jurisdictions-access.json',
      verificationSMS: '/billfold-api/player/sendVerificationSms',
      verifySMS: '/billfold-api/player/verifySmsShortCode',
      trustlyLoggedIn: '/billfold-api/payment/loginStatus'
    };

    function getWallet (trustly) {
      return model.getWallet(true).then(
        function () {
          if ((wallet && Object.keys(wallet).length > 0)) {
            model.getDetails();
            return { trustly: trustly }
          }
          return false;
        }, function () {
          loggedIn = false;
          return false;
        }
      );
    }

    var INIT_ONE_SIGNAL_COUNT = 0;

    model.initOneSignal = function () {
      var OneSignal = window.OneSignal;
      if (!OneSignal) {
        INIT_ONE_SIGNAL_COUNT += 1;
        return INIT_ONE_SIGNAL_COUNT < 100 ? setTimeout(model.initOneSignal, 200) : null;
      }
      OneSignal.push(function() {
        OneSignal.init({
          appId: '2fd027d9-b007-48dc-8611-dbba842cd32b'
        });
      });
    };

    var SEND_ONE_SIGNAL_COUNT = 0;
    model.sendOneSignalTag = function () {
      var OneSignal = window.OneSignal
      return OneSignal ? model.getDetails().then(function (response) {
        SEND_ONE_SIGNAL_COUNT += 1;
        if (!response || !response.email) {
          return SEND_ONE_SIGNAL_COUNT < 100 ? setTimeout(model.sendOneSignalTag, 5000) : null;
        }
        if (!response.nickName && response.email) {
          return model.updateFields({ nickName: md5.createHash(response.email) }, true).then(function () {
            model.sendOneSignalTag();
          });
        }

        var NickName = response.nickName || md5(response.email)

        if (NickName) {
          OneSignal.push(function() {
            OneSignal.sendTag('NickName', NickName);
          });
        }
      }) : null;
    };

    model.isLoggedIn = function (update) {
      if (!update) {
        return $q.when(loggedIn);
      }
      return getWallet(false)
    };


    model.cleanFreeSpins = function () {
      freeSpins = null;
      freeSpinsCount = null;
      var httpCache = CacheFactory.get('http');
      httpCache.remove(URLS.bonuses);
    };

    model.clean = function () {
      loggedIn = false;
      balance = null;
      wallet = null;
      details = null;
      myDetailsFormFields = null;
      country = null;
      paymentDetails = null;
      loyalty = null;
      loyaltyRate = null;
      withdrawalNeededTypes = null;
      $rootScope.myDetailsFormFields = null;
      model.cleanFreeSpins();

      var httpCache = CacheFactory.get('http');
      httpCache.remove('phoneActivation');
    };

    model.getPhoneCodeByCountry = function(countryCode) {
      return (Const.phoneCodes[countryCode] || '').replace(/\s+/g, '');
    };

    model.askEmailModalIsOpened = false;

    model.askEmail = function (details) {
      return fpModal.open({
        templateUrl: '/app/modals/pay-play-email/pay-play-email.tmpl.html',
        size: 'md',
        noCloseBtn: true,
        backdrop: 'static',
        blocker: true,
        resolve: {
          details: function () { return details; }
        },
        controller: function ($scope, details, User, Notifier, fpModal) {
          $scope.detailFields = [
            {
              key: 'email',
              type: 'email',
              templateOptions: {
                icon: 'email'
              },
              validation: {
                messages: {
                  email: '"ERR.VALIDATION.EMAIL"'
                }
              },
              data: {
                translateField: 'EMAIL'
              }
            }
            // {
            //   key: 'phoneNumber',
            //   type: 'input-phone',
            //   data: {
            //     translateField: 'PHONE_NUMBER'
            //   }
            // }
          ];
          $scope.submit = submit;

          function submit() {
            if (!details.nickName) {
              $scope.details.nickName = md5.createHash($scope.details.email);
            }
            return model.updateFields($scope.details, true).then(function (data) {
              if (data.hasOwnProperty('error')) {
                Notifier.danger(data.message, data.replacements);
                return false;
              } else {
                fpModal.close();
                Notifier.success('APP.FORM.MY_DETAILS.SUCCESS', data.replacements);
                model.sendOneSignalTag();
                return true;
              }
            });
          }
        }
      });
    };

    model.getDetails = function (update) {
      if (!update && details) {
        return $q.when(details);
      }

      return $ajax({
        method: 'GET',
        url: URLS.details,
        cache: !update,
        filter: function (response) {
          if (response.hasOwnProperty('error')) {
            response = {};
          }

          if (response.registrationSource === 'payment' && !$rootScope.isPayAndPlay) {
            $timeout(function () { $rootScope.isPayAndPlay = true; }, 1);
          }

          if (response.registrationSource === 'payment') {
            if (!response.email && !model.askEmailModalIsOpened) { // && !response.phone) {
              model.askEmailModalIsOpened = true;
              setTimeout(function () {
                model.askEmail(response);
              }, 5000);
            }
          }

          details = response;

          return details;
        }
      });
    };

    /**
     * Balance and wallet
     */

    model.lowBalanceShown = false;
    model.lowBalanceModalOpened = false;

    model.openLowBalanceModal = function () {
      if ($rootScope.isWithdrawalModalOpened || !$rootScope.isPayAndPlay) {
        return;
      }

      model.lowBalanceModalOpened = true;

      return fpModal.open({
        templateUrl: '/app/modals/payandplay-deposit/payandplay-deposit.tmpl.html',
        size: 'md',
        controller: function ($scope, $state, /* method, country, currency, */ fpModal, User, Deposit, Payment, Notifier) {
          $scope.method = {};
          $scope.country = '';
          $scope.currency = '';
          $scope.thinking = true;
          $scope.deposit = false;

          $scope.onDeposit = onDeposit;

          init();

          function init () {
            model.getCountry().then(function (_country) {
              $scope.country = _country;
              Deposit.getDetails(true).then(function (result) {
                console.log(result)
                $scope.currency = result.currency;
                $scope.method = result.methods.filter(function (m) {
                  return m.provider === 'trustly' && m.payAndPlay;
                })[0] || {};

                // console.log($scope.method, $scope.currency)

                $scope.thinking = false;
              });
            });
          }

          function onDeposit (data) {
            $scope.deposit = true;
            Payment.deposit(data).then(function(response){
              Notifier.showError(response);
              fpModal.close();
              return response.hasOwnProperty('success');
            });
          }
        }
      }).result.then(function () {
        model.lowBalanceShown = false;
        model.lowBalanceModalOpened = false;
      }, function () {
        model.lowBalanceShown = true;
        model.lowBalanceModalOpened = false;
      });
    };

    model.getBalance = function (update) {
      if (!update && balance) {
        return $q.when(balance);
      }

      return $ajax({
        method: 'GET',
        url: URLS.balance,
        cache: !update,
        filter: function (response) {
          if (response.hasOwnProperty('error')) {
            if (response.hasOwnProperty('errorCode')){
              response = {errorCode: response.errorCode};
            } else {
              response = {};
            }
            wallet = {};
          } else {
            if (!balance) {
              balance = {};
            }
            if (response.cash !== balance.cash || response.promo !== balance.promo) {
              balance = response;
              setWallet();
            } else {
              balance = response;
            }
          }

          if ($rootScope.isPayAndPlay && balance && balance.currency) {
            var d = balance.currency === 'SEK' ? 10 : 1
            var expireDate = new Date();
            expireDate.setDate(expireDate.getDate() + 365);

            if (balance.balance / d <= 3) {
              $cookies.put('blnc', 'true', { expires: expireDate, path: '/' });

              if (balance.balance === 0 && !model.lowBalanceModalOpened && !model.lowBalanceShown) {
                model.lowBalanceModalOpened = true;
                setTimeout(function () {
                  model.openLowBalanceModal();
                }, 5000);
              }
            } else {
              $cookies.put('blnc', 'false', { expires: expireDate, path: '/' });
            }

          }
          return response;
        }
      });

      function setWallet() {
        if (balance && balance !== {}){
          wallet = angular.copy(balance);
          wallet.balance = (parseFloat(wallet.balance) || 0).toFixed(2);
          wallet.availableWithdrawal = (parseFloat(wallet.availableWithdrawal) || 0).toFixed(2);
          wallet.cash = (parseFloat(wallet.cash) || 0).toFixed(2);
          wallet.promo = (parseFloat(wallet.promo) || 0).toFixed(2);
          wallet.percentageWR = calculateWageringRequirement(wallet.currentTurnover, wallet.totalTurnover);
          wallet.currencySymbol = Const.currencies[wallet.currency] || wallet.currency;
        } else {
          wallet = {};
        }

        // Returns percentage of current turnover limit.
        // (How much wagering is required before you can withdraw your bonus funds. 100% means you can withdraw and 0% means you have a long way to go)
        function calculateWageringRequirement(remaining, total) {
          remaining = parseFloat(remaining) || 0;
          total = parseFloat(total) || 0;

          if (!total) {
            return null;
          }
          return Math.floor(100 - remaining * 100 / total);
        }
      }
    };

    model.getWallet = function (update) {
      return model.getBalance(update).then(function(){
        return wallet || {};
      });
    };


    /**
     * Contact Us
     */

    // POST: "firstName", "lastName", "email", "subjectId", "subject", "body", "sendMeCopy"
    model.contactUs = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.contactUs,
        data: params
      });
    };

    /**
     * My Details
     */
    model.getMyDetailsFormFields = function (update) {
      if (!update && myDetailsFormFields) {
        return $q.when(myDetailsFormFields);
      }

      return $ajax({
        method: 'GET',
        url: URLS.initDetails,
        cache: !update,
        filter: function (response) {
          if (response.hasOwnProperty('error')) {
            response = {};
          }
          $rootScope.myDetailsFormFields = myDetailsFormFields = response;
          return myDetailsFormFields;
        }
      });
    };

    // POST: <user details> ...
    model.updateDetails = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.updateDetails,
        data: params
      }).then(function (response) {
        if (response.hasOwnProperty('success')) {
          // Update campaigns data (in case of refusal to participate in campaigns)
          // Storage('Payment').data.remove('depositDetails');
          // Update stored details
          return model.getDetails(true).then(function () {
            return response;
          });
        }
        return response;
      });
    };

    // Update given list of fields only (instead of updateDetails that updates all required fields at once)
    model.updateFields = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.updateFields,
        data: params
      });
    };

    model.closeAccount = function (params, kind) {
      return fpModal.open({
        templateUrl: '/app/modals/check-password/check-password.tmpl.html',
        size: 'md',
        resolve: {
          kind: function () {
            return kind
          }
        },
        controller: function ($scope, $state, kind) {
          $scope.kind = kind;
          $scope.toResponsibleGambling = function () {
            $state.go('static.responsible-gaming');
          }

        }
      }).result.then(function(data){
        if ($rootScope.isPayAndPlay) {
          return model.closeAccountRequest(params);
        }
        if (data && data.hasOwnProperty('password')) {
          params.password = data.password;
          return model.closeAccountRequest(params);
        }
      });
    };



    model.coolOffDaysRequest = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.coolOffDays,
        data: params
      }).then(function (response) {
        return response;
      });
    };

    model.coolOffDays = function (params, kind) {
      return fpModal.open({
        templateUrl: '/app/modals/check-password/check-password.tmpl.html',
        size: 'md',
        resolve: {
          kind: function () {
            return kind
          }
        },
        controller: function ($scope, $state, kind) {
          $scope.kind = kind;
          $scope.toResponsibleGambling = function () {
            $state.go('static.responsible-gaming');
          }

        }
      }).result.then(function(data){
        if (data && data.hasOwnProperty('password')) {
          params.password = data.password;
          return model.coolOffDaysRequest(params);
        } else if ($rootScope.isPayAndPlay) {
          return model.coolOffDaysRequest(params);
        }
      });
    };

    model.closeAccountRequest = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.close,
        data: params
      }).then(function (response) {
        return response;
      });
    };

    // POST: "oldPassword", "password", "confirmPassword", "birthDate"
    model.updatePassword = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.updatePassword,
        data: params
      });
    };

    // POST: "email" | "nickname"
    model.checkForDuplication = function (name, value) {
      var data = {};
      name = name.toLowerCase();
      data[name] = value;

      return $ajax({
        method: 'POST',
        url: URLS.duplicationCheck.replace(/:name/, name),
        data: data
      });
    };

    model.getCountry = function (update) {
      //if (!update && country) {
      //  return $q.when(country);
      //}

      return $ajax({
        method: 'GET',
        url: URLS.country,
        cache: false,  //!update,
        filter: function (response) {
          return model.getDetails(true).then(function (details) {
            if (details && details.country === 'GBR') {
              return 'GBR';
            }

            if (response.hasOwnProperty('error')) {
              response = { country: '' };
            }

            country = response.country;
            return country;
          });
        }
      });
    };

    model.getJurisdictionsAccess = function (update) {
      if (!update && jurisdictionsAccess) {
        return $q.when(jurisdictionsAccess);
      }

      return $ajax({
        method: 'GET',
        url: URLS.jurisdictionsAccess,
        cache: !update,
        filter: function (response) {
          if (response.hasOwnProperty('error')) {
            response = {};
          }
          jurisdictionsAccess = response;
          return jurisdictionsAccess;
        }
      });
    };

    model.getPaymentDetails = function (update) {
      if (!update && paymentDetails) {
        return $q.when(paymentDetails);
      }

      return $ajax({
        method: 'GET',
        url: URLS.paymentDetails,
        cache: !update,
        filter: function (response) {
          if (response.hasOwnProperty('error')) {
            response = [];
          }
          paymentDetails = response;
          return paymentDetails;
        }
      });
    };

    // POST: "detailType", <generated fields> ...
    model.updatePaymentDetails = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.updatePaymentDetails,
        data: params
      }).then(function (response) {
        if (response.hasOwnProperty('success')) {
          // Update stored details
          return model.getDetails(true).then(function () {
            return response;
          });
        }
        return response;
      });
    };

    model.bonusCancel = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.bonusCancel,
        data: params,
        filter: function (response) {
          return response;
        }
      });
    };

    model.getFreeSpins = function (update) {
      if (!update && freeSpins) {
        return $q.when(freeSpins);
      }

      return $ajax({
        method: 'GET',
        url: URLS.bonuses,
        cache: !update,
        filter: function (response) {
          freeSpins = freeSpins || {};
          if (response.hasOwnProperty('bonuses')) {
            freeSpins = response.bonuses;
          }
          return freeSpins;
        }
      });
    };

    model.getFreeSpinsCount = function (update) {
      if (!update && (freeSpinsCount || freeSpinsCount === 0)) {
        return $q.when(freeSpinsCount);
      }

      return model.getFreeSpins(update).then(function(){
        if (!freeSpins || !freeSpins.hasOwnProperty('transactions') || freeSpins.transactions.length === 0) {
          freeSpinsCount = 0;
        } else {
          freeSpinsCount = 0;
          angular.forEach(freeSpins.transactions, function(transaction){
            // if there is any games for given freespins we add number of freespins to counter
            if (transaction.games && transaction.games.length) {
              freeSpinsCount += transaction.freeSpins;
            }
          });
        }

        return freeSpinsCount;
      });
    };

    /**
     * Loyalty
     */
    model.getLoyalty = function (update) {
      if (!update && loyalty) {
        return $q.when(loyalty);
      }

      return $ajax({
        method: 'GET',
        url: URLS.loyalty,
        cache: !update,
        filter: function (response) {
          loyalty = {};
          if (response.hasOwnProperty('success')) {
            loyalty = response;
          }
          return loyalty;
        }
      });
    };

    model.getLoyaltyRate = function (update) {
      if (!update && loyaltyRate) {
        return $q.when(loyaltyRate);
      }

      return $ajax({
        method: 'GET',
        url: URLS.loyaltyRate,
        cache: !update,
        filter: function (response) {
          loyaltyRate = {};
          if (!response.hasOwnProperty('error')) {
            loyaltyRate = response;
          }
          return loyaltyRate;
        }
      });
    };

    // POST: "pointAmount", "loyaltyType"
    model.convertLoyaltyPoints = function (amount, type) {
      var data = {
        pointAmount: amount || 0,
        loyaltyType: type
      };

      return $ajax({
        method: 'POST',
        url: URLS.convertLoyalty,
        data: data
      }).then(function (response) {
        if (response.hasOwnProperty('success')) {
          // Update loyalty (award) points
          return model.getWallet(true).then(function (wallet) {
            return wallet;
          });
        }
        return response;
      });
    };

    model.getDocuments = function () {
      return $ajax({
        method: 'GET',
        url: URLS.documents,
        cache: false,
        filter: function (response) {
          return response;
        }
      });
    };

    model.getDocumentTypes = function () {
      function fullTypeOfDocument(doc) {
        var docType = doc.documentType;

        if (docType === 'creditCard') {
          docType = 'creditCardFront';
          if (doc.name && doc.name.indexOf('cb_') === 0) {
            docType = 'creditCardBack';
          }
        }

        return docType;
      }

      return model.getDocuments().then(function(response){
        var types = [];
        angular.forEach(response, function(doc){
          var docType = fullTypeOfDocument(doc);
          if (types.indexOf(docType) === -1) {
            types.push(docType);
          }
        });
        return types;
      });
    };

    model.myAffiliate = function () {
      var url = window.location.href,
        myAffiliateToken = Fn.getUrlParam(url, 'token'),
        myAffiliateId = Fn.getUrlParam(url, 'user_id');

      if (myAffiliateToken && myAffiliateId) {
        return $ajax({
          method: 'POST',
          url: URLS.myAffiliate,
          data: {
            myAffiliateToken: myAffiliateToken,
            myAffiliateId: myAffiliateId
          }
        });
      }
    };

    model.setWithdrawalNeededTypes = function (neededTypes) {
      withdrawalNeededTypes = neededTypes;
    };

    model.getWithdrawalNeededTypes = function () {
      return withdrawalNeededTypes || [];
    };

    model.sendVerificationSMS = function () {
      return $ajax({
        method: 'GET',
        url: URLS.verificationSMS,
        cache: false
      });
    };

    model.verifySMS = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.verifySMS,
        data: params
      });
    };

    model.getCardholderName = function (firstName) {
      if (!firstName) {
        return '';
      }
      var fName = firstName.trim().split(' ');
      if (!fName || !fName.length) {
        return '';
      }
      return fName[0] || '';
    };

    model.getCardholderSurname = function (lastName) {
      if (!lastName) {
        return '';
      }
      var lName = lastName.trim().split(' ');
      if (!lName || !lName.length) {
        return '';
      }
      lName = lName.pop();
      return lName;
    };

  });

})();
