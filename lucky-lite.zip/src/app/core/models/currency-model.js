(function() {
  'use strict';

  angular.module('finnplay.models.currency', [
  ])

  .service('Currency', function($q, $ajax, Const){
    var model = this,
        currencies;

    var URLS = {
      currencies: '/billfold-api/config/currencies'
    };

    model.getSymbol = function (id) {
      return Const.currencies[id] || id;
    };

    model.getList = function (update) {
      if (!update && currencies) {
        return $q.when(currencies);
      }

      return $ajax({
        method: 'GET',
        url: URLS.currencies,
        filter: function (response) {
          currencies = [];
          if (!response.hasOwnProperty('error') && angular.isArray(response.currencies)) {
            currencies = response.currencies;
          }
          return currencies;
        }
      });
    };

    // Returns multiplied or divided amount dependend on currency by currency multiplier
    // F.e. if currency is SEK and multiply is true - then return amount*10
    // F.e. if currency is EUR and multiply is false - then return amount/10
    // @param Number - amount
    // @param String - currency code
    // @param Boolean - true: multiple, false:divide
    // @return Number - new amount
    model.changeAmount = function(amount, currency, multiply){
      return amount;
      //var multiplier = Const.currencyMultipliers[currency] || 1;
      //
      //if (!multiply) {
      //  multiplier = multiplier / Const.currencyDivider;
      //}
      //
      //return amount * multiplier;
    };

  });

})();