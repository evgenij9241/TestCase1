(function() {
  'use strict';

  angular.module('finnplay.models.deposit', [
  ])

  .service('Deposit', function($q, $ajax, CacheFactory, User){
    var model = this,
        prefillingFormFields,
        details,
        methods,
        campaigns,
        giftsCount;

    var URLS = {
      initPrefill: '/billfold-api/payment/initPrefillDeposit',
      updatePrefill: '/billfold-api/payment/prefillDeposit',
      listStoredPaymentDetails: '/billfold-api/payment/listStoredPaymentDetails',
      validateAddress: '/billfold-api/player/validateAddress',
      details: '/billfold-api/payment/methods',
      initDeposit: '/billfold-api/payment/initDeposit',
      deposit: '/billfold-api/payment/confirmDeposit'
    };

    var BANK_ACCOUNTS_METHOD_ID = 240002;
    var BANK_ACCOUNTS_METHOD_PROVIDERS = [ 'epro', 'lateral_hpp' ];

    var LAST_GAME_CACHE_KEY = 'lastGame';

    var cache = new CacheFactory('deposit');

    var PREFILLED_METHODS = {
      370001: 'epro',
      240002: 'lateral_hpp'
    };

    /**
     * Campaigns
     */

    model.getCampaigns = function (update) {
      if (!update && campaigns) {
        return $q.when(campaigns);
      }

      return model.getDetails(update).then(function () {
        if (angular.isObject(details) && details.campaigns && angular.isArray(details.campaigns) && details.campaigns.length > 0) {
          campaigns = details.campaigns;
        } else {
          campaigns = [];
        }
        return campaigns;

      });
    };

    model.getBonusCampaigns = function (update) {
      return model.getCampaigns(update).then(function(){
        var bonusCampaigns = [];
        angular.forEach(campaigns, function(campaign){
          if (campaign.campaignId && !campaign.promoCode) {
            bonusCampaigns.push(campaign);
          }
        });
        return bonusCampaigns;
      });
    };

    model.getCampaignById = function (campaignId) {
      return model.getCampaigns().then(function(){
        var selectedCampaign;
        angular.forEach(campaigns, function(campaign){
          if (campaignId === campaign.campaignId) {
            selectedCampaign = campaign;
          }
        });
        return selectedCampaign;
      });
    };

    model.getGiftsCount = function (update) {
      if (!update && giftsCount) {
        return $q.when(giftsCount);
      }

      return model.getBonusCampaigns(update).then(function(bonusCampaigns){
        giftsCount = bonusCampaigns.length;
        return giftsCount;
      });
    };

    model.getDetailsCurrency = function () {
      if (!details) { return null; }
      return details.currency;
    };

    model.getMethods = function () {
      return model.getDetails().then(function () {
        if (details.methods && angular.isArray(details.methods) && details.methods.length > 0) {
          methods = details.methods;
          return methods;
        }
      });
    };

    model.storedPaymentDetails = function () {
      return $ajax({
        method: 'GET',
        url: URLS.listStoredPaymentDetails,
        cache: false,
        filter: function (response) {
          if (response.hasOwnProperty('error')) {
            return null;
          }
          return response.storedPaymentDetails || null;
        }
      });
    };

    model.getBankAccountsMethodId = function () {
      return BANK_ACCOUNTS_METHOD_ID;
    };

    model.getBankAccountsMethod = function () {
      return getMethodById(BANK_ACCOUNTS_METHOD_ID);
    };

    model.getStoredBankCards = function (methodId) {
      return model.storedPaymentDetails().then(function (storedPaymentDetails) {
        //For quick deposit
        if (!methodId) return storedPaymentDetails || [];

        if (!storedPaymentDetails || !Array.isArray(storedPaymentDetails) || !PREFILLED_METHODS[methodId]) return [];

        storedPaymentDetails = storedPaymentDetails.filter(function (stored) {
          return stored.paymentProviderName === PREFILLED_METHODS[methodId];
        }) || [];

        return storedPaymentDetails.map(function (stored) {
          return {
            name: stored.description.replace(/[x, X]/g, '*'),
            value: stored.storedDetailReference
          }
        })
      });
      //return model.getMethods().then(function () {
      //  var stored = [];
      //  var method = getMethodById(methodId || BANK_ACCOUNTS_METHOD_ID);
      //  if (method && method.stored && angular.isArray(method.storedData)) {
      //    angular.forEach(method.storedData, function(value){
      //      var reference = value.reference,
      //          identifier = value.cardEnding || value.accountNumber;
      //      if (reference && identifier) {
      //        stored.push({name: 'xxxx' + identifier, value: reference});
      //      }
      //    });
      //    return stored;
      //  } else {
      //    return [];
      //  }
      //});
    };

    model.isBankAccountsMethodId = function (methodId) {
      return BANK_ACCOUNTS_METHOD_PROVIDERS.indexOf(methodId) > -1;
    };


    /**
     * Deposit Prefill
     */

    model.getPrefillingFormFields = function (update) {
      if (!update && prefillingFormFields) {
        return $q.when(prefillingFormFields);
      }

      return $ajax({
        method: 'GET',
        url: URLS.initPrefill,
        cache: !update,
        filter: function (response) {
          prefillingFormFields = response;
          if (response.hasOwnProperty('error')) {
            prefillingFormFields = {};
          }
          return prefillingFormFields;
        }
      });
    };

    // POST: <user details> ...
    model.checkPrefillingData = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.validateAddress,
        data: params
      });
    };

    // POST: <user details> ...
    model.updatePrefillingData = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.updatePrefill,
        data: params
      }).then(function(response) {
        if (response.hasOwnProperty('success')) {
          return model.getDetails(true).then(function () {
            return response;
          });
        }
        return response;
      });
    };

    /**
     * Deposit
     */

    var COUNTRY_METHODS = [
      10001 /*paysafecard*/,
      110002 /*neteller*/,
      70002 /*skrill*/,
      240001 /*ecopayz*/,
      130006 /*sofort*/,
      130005 /*giropay*/,
      130016 /*safetypay*/,
      240002 /*visa/master*/,
      190001 /*visa/master*/,
      410006 /*muchbetter*/
    ]

    function filterMethodsForCountry (details) {
      return User.getDetails(true).then(function (userDetails) {
        return User.getCountry().then(function (country) {
          if (userDetails.country === 'DEU' || country === 'DEU') {
            details.methods = details.methods.filter(function (method) {
              return COUNTRY_METHODS.indexOf(method.method) > -1;
            });
          }
          return details;
        });
      });
    }


    model.getDetails = function (update) {
      if (!update && details) {
        return $q.when(details);
      }

      return $ajax({
        method: 'GET',
        url: URLS.details,
        cache: !update,
        filter: function (response) {
          details = response;
          return filterMethodsForCountry(details);
        }
      });
    };

    // POST: amount, method
    model.initDeposit = function (params) {
      // Add two decimals to the amount
      params.amount = parseFloat(params.amount).toFixed(2);

      return $ajax({
        method: 'POST',
        url: URLS.initDeposit,
        data: params
      });
    };

    // POST: amount, method, <user details> ...
    model.deposit = function (params) {
      // Add two decimals to the amount
      params.amount = parseFloat(params.amount).toFixed(2);

      return $ajax({
        method: 'POST',
        url: URLS.deposit,
        data: params
      });
    };

    model.getLastGameState = function () {
      return cache.get(LAST_GAME_CACHE_KEY);
    };

    model.setLastGameState = function (stateParams) {
      if (stateParams) {
        cache.put(LAST_GAME_CACHE_KEY, stateParams);
      } else {
        cache.remove(LAST_GAME_CACHE_KEY);
      }
    };

    function quickDepositStoredMethods (storedMethods) {}

    function getMethodById(methodId) {
      if (!methods || methods.length === 0) {
        return {};
      }

      for (var i = 0, len = methods.length; i < len; i++) {
        if (methods[i].method === methodId) {
          return methods[i];
        }
      }

      return {};
    }

  });

})();
