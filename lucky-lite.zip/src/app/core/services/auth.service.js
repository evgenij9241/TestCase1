(function() {
'use strict';

angular.module('finnplay.core.services.auth', [])

.service('Auth', function ($rootScope, $state, $timeout, $ajax, $cookies, CacheFactory, User, Landing, Game) {
  var model = this,
      credentials;

  var URLS = {
    login: '/billfold-api/login',
    logout: '/billfold-api/logout',
    forgotPassword: '/billfold-api/player/triggerForgotPassword',
    resetPassword: '/billfold-api/player/modifyForgotPassword'
  };

  var TINY_BALANCE = 1;

  function loginCookie () {
    var expireDate = new Date();
    expireDate.setDate(expireDate.getDate() + 365);
    $cookies.put('existing-user', Math.floor(Math.random() * 6) + 1 + '', {'expires': expireDate});
  }

  model.loginByToken = function (data) {
    return $ajax({
      method: 'POST',
      url: URLS.login,
      data: data,
    }).then(function (response) {
      if (response.hasOwnProperty('success')) {
        credentials = null;
        User.clean();
        Landing.clearLandingCookies();
        $rootScope.isLoggedIn = true;
        $rootScope.isPayAndPlay = true;
        User.sendOneSignalTag();
      }
      return response;
    });
  }

  // POST: "email", "password"
  model.login = function (params, redirectToLoginOnError) {
    return $ajax({
      method: 'POST',
      url: URLS.login,
      data: params
    }).then(function (response) {
      if (response.hasOwnProperty('success')) {
        credentials = null;
        User.clean();
        Landing.clearLandingCookies();
        $rootScope.isLoggedIn = true;
        $rootScope.isPayAndPlayCountry ? $rootScope.isPayAndPlay = true : $rootScope.isPayAndPlay = false;
        User.sendOneSignalTag();

        //Set cookie for any login
        loginCookie();

        if ($rootScope.signupFlow) {
          $state.go('deposit');
          return response;
        } else {
          return User.getWallet(true).then(function (wallet) {
            if (wallet.balance < TINY_BALANCE) {
              $state.go('deposit');
            } else {
              $state.go('start');
            }
            return response;
          });
        }
      }

      // T&C acceptance error
      if (response.errorCode === 155 || response.errorCode === 214) {
        credentials = params;
        switch(response.errorCode) {
          case 155:
            $state.go('terms-acceptance');
            break;
          case 214:
            $state.go('ukgc-license');
            break;
          default: break;
        }

        // Return an empty object to prevent the display of the error message (notice), because will be redirect
        return {};
      }
      else if (redirectToLoginOnError && $state._current.name !== 'login') {
        $state.go('login');
      }
      return response;
    });
  };

  model.logout = function () {
    $rootScope.isLoggedIn = false;
    $rootScope.isPayAndPlay = false;
    delete $rootScope.signupFlow;

    document.documentElement.classList.add('loading');
    return $ajax({
      method: 'POST',
      url: URLS.logout
    }).then(function (response) {
      if (response.hasOwnProperty('success')) {

        User.clean();
        Game.clean();
        $ajax();

        $rootScope.isPayAndPlay = false;

        //var httpCache = CacheFactory.get('http');
        //httpCache.removeAll();
        $timeout(function () {
          $state.go('home');
        }, 1000);
      }
      return response;
    });
  };

  model.loginWithCredentials = function(license) {
    var data = {
      email: credentials.email,
      password: credentials.password,
      policyChecked: true
    }

    if (license) {
      delete data.policyChecked;
      data.licenseChecked = true;
    }

    return model.login(data);
  };

  model.hasCredentials = function() {
    return !!credentials;
  };

  /**
   * Forgot Password
   */

  // POST: "email", "birthDate"
  model.forgotPassword = function (params) {
    return $ajax({
      method: 'POST',
      url: URLS.forgotPassword,
      data: params
    });
  };

  // POST: "password", "confirmPassword", "activationCode"
  model.resetPassword = function (params) {
    return $ajax({
      method: 'POST',
      url: URLS.resetPassword,
      data: params
    });
  };
});
})();
