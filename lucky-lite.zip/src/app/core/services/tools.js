(function() {
  'use strict';

  angular.module('finnplay.core.services.tools', [])

    .service('Tools', function ($q, fpModal, Game) {


      function getRetinaUrl (url) {
        var extension = url.split('.').pop().split(/#|\?/)[0];
        return url.replace('.' + extension, '') + '@2x.' + extension;
      }

      function getfilename (url) {
        return url.split('/').pop();
      }

      function getImage (url) {
        try {
          var http = new XMLHttpRequest();
          http.open('HEAD', url, false);
          http.send();
          return http.status !== 404;
        } catch (e) {
          return false;
        }
      }

      function showStatusModal(table) {
        return fpModal.open({
          template: '<div class="fp-modal__content"><a ng-if="table.length" href="" id="downloadResult" ng-click="download()">Download file</a><p ng-if="!table.length">All images exist</p><div ng-if="table.length"><p ng-repeat="row in table">{{row}}</p></div></div>',
          size: 'md',
          resolve: {
            table: function () {
              return table
            }
          },
          controller: function ($scope, table) {
            $scope.table = table
            $scope.download = function () {
              var a = document.getElementById('downloadResult');
              var file = new Blob([table.join('\n')], {type: 'text/plain'});
              a.href = URL.createObjectURL(file);
              a.download = 'missing-images.csv';
            }
            console.log(table)
          }
        });
      }



      window.getUnavailableImages = function (enabled) {
        console.log('LOADING...');
        Game.toolGetGames(enabled).then(function (games) {
          console.log(games)
          var result = [];

          result.push('Filename,ProviderID,Image@1x,Image@2x');

          games.filter(function (g) { return enabled ? !g.gameDisabled : true; }).forEach(function (game) {
            var url = Game.getGameImageUrl(game.name, game.provider);
            var retinaUrl = getRetinaUrl(url);

            var imageOk = getImage(url);
            var retinaImageOk = getImage(retinaUrl);

            if (!imageOk || !retinaImageOk) {
              result.push(getfilename(url) + ',' + game.provider + ',' + (imageOk ? 'OK' : 'Missing') + ',' + (retinaImageOk ? 'OK' : 'Missing'))
            }
          })
          showStatusModal(result);
        });
      }
    });
})();
