(function() {
  'use strict';

  angular.module('finnplay.core.services.register', [])

  .service('Register', function ($q, $state, $ajax, $rootScope, $cookies, $filter, User, Const, Currency) {
    var model = this,
      campaigns,
      formFields,
      credentials;

    console.log()

    var URLS = {
      initRegister: '/billfold-api/player/initRegister',
      register: '/billfold-api/player/registerPlayer',
      activate: '/billfold-api/player/activate',
      autoLogin: '/billfold-api/autoLogin',
      temporaryDomains: Const.ENV.staging ? '/data/temporary-domains.json' : 'https://www.luckycasino.com/cms/static/en/temporary-domains.json'
    };

    model.initRegister = function () {
      return $ajax({
        method: 'GET',
        url: URLS.initRegister,
        cache: false
      });
    };

    model.getFormFields = function (update) {
      if (!update && formFields) {
        return $q.when(formFields);
      }

      return $ajax({
        method: 'GET',
        url: URLS.initRegister,
        cache: !update
      }).then(function (response) {
        if (response.hasOwnProperty('error')) {
          return response;
        }
        campaigns = response.campaigns || [];
        formFields = response;
        return formFields;
      });
    };

    model.getCampaigns = function (update) {
      if (!update && campaigns) {
        return $q.when(campaigns);
      }

      return model.getFormFields(update).then(function (response) {
        if (response.hasOwnProperty('error')) {
          return response;
        }
        return campaigns;
      });
    };

    // POST: <t: token>
    model.autoLogin = function (token) {
      return $ajax({
        method: 'POST',
        url: URLS.autoLogin,
        data: {t: token}
      }).then(function (response) {
        if (response.hasOwnProperty('success')) {
          credentials = null;
          User.clean();
          $rootScope.isLoggedIn = true;

          $state.go('deposit');
          return response;
        }

        // T&C acceptance error
        if (response.errorCode === 155) {
          $state.go('terms-acceptance');
          // Return an empty object to prevent the display of the error message (notice), because will be redirect
          return {};
        }
        return response;
      });
    };

    // POST: <user details> ...
    model.register = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.register,
        data: params
      }).then(function (response) {
        if (response.hasOwnProperty('success')) {
          credentials = params;
          // if (response.hasOwnProperty('t')) {
          //   return model.autoLogin(response.t);
          // } else {
            $state.go('account-activation');
          // }
        }
        return response;
      });
    };

    model.activateAccount = function (params) {
      return $ajax({
        method: 'POST',
        url: URLS.activate,
        data: params
      });
    };

    model.getTemporaryEmailDomains = function () {
      return $ajax({
        method: 'GET',
        url: URLS.temporaryDomains
      }).then(function (response) {
        return response;
      }, function () {
        return [];
      });
    };

    model.getCredentials = function () {
      return credentials;
    };

    model.getCampaignGames = function (title) {
      if (!title || !title.match(/(s-|a-)*(\d{5,10})/g)) {
        return [];
      }

      var parts = title.match(/(s-|a-)*(\d{5,10})/g),
        result = [];
      parts.forEach(function (part) {
        if (part && part.replace(/\D/g, '')) {
          result.push(parseInt(part.replace(/\D/g, '')));
        }
      });
      return result;
    };

    model.makePromoFreeSpinCampaigns = function (campaigns, pattern, affiliate) {
      if (!campaigns) {
        return null;
      }

      return campaigns.map(function (promo) {
        return {
          value: promo.freeSpinAmount,
          title: promo.title.replace(pattern, ''),
          games: model.getCampaignGames(promo.title),
          campaignId: promo.campaignId,
          affiliate: affiliate
        }
      });
    };

    model.makePromoMoneyCampaigns = function (campaigns, pattern, currency, affiliate) {
      if (!campaigns) {
        return null;
      }

      var currencySymbol = Currency.getSymbol(currency);

      return campaigns.map(function (promo) {
        return {
          value: $filter('currency')(promo.promoAmount, currencySymbol, 0),
          title: promo.title.replace(pattern, ''),
          games: model.getCampaignGames(promo.title),
          campaignId: promo.campaignId,
          affiliate: affiliate,
          currency: currency
        }
      });
    };

    function setCurrencyByCountry(countryCode) {
      if (!countryCode) { return; }
      var currency = 'USD'; // Default currency for other countries
      if (Const.countryCurrencies.hasOwnProperty(countryCode)) { currency = Const.countryCurrencies[countryCode]; }
      return currency;
    }

    model.getPromoByCurrency = function (campaigns, currency) {
      if (!campaigns || !currency) {
        return null;
      }
      return campaigns.filter(function (campaign) {
        return campaign.currency.indexOf(currency) > -1;
      });
    }


    model.getPromoGameCampaigns = function (campaigns) {
      var affiliateFreeSpins = null,
        affiliateMoney = null,
        signupFreeSpins = null,
        signupMoney = null;
      return User.getCountry().then(function (countryCode) {
        var currency = setCurrencyByCountry(countryCode);

        if ($cookies.get('existing-user')) return null;

        if (campaigns && campaigns.length) {
          var campaignsByUserCurrency = model.getPromoByCurrency(campaigns, currency);

          //If affiliate campaigns
          //Money
          affiliateMoney = model.getMarkedCampaign(/(a-m)/g, campaignsByUserCurrency);
          affiliateMoney = model.makePromoMoneyCampaigns(affiliateMoney, /(s-m|a-m)/g, currency, true);

          if (affiliateMoney && affiliateMoney[0]) {
            return affiliateMoney[0]
          }

          //Freespins
          affiliateFreeSpins = model.getMarkedCampaign(/(a-)+(\d{5,10})*(-\d{5,10})/g, campaigns);
          affiliateFreeSpins = model.makePromoFreeSpinCampaigns(affiliateFreeSpins, /(s-|a-)+(\d{5,10})*(-\d{5,10})/g, true);

          if (affiliateFreeSpins && affiliateFreeSpins[0]) {
            return affiliateFreeSpins[0]
          }

          //if signup campaigns
          //Money
          signupMoney = model.getMarkedCampaign(/(s-m)/g, campaignsByUserCurrency);
          signupMoney = model.makePromoMoneyCampaigns(signupMoney, /(s-m|a-m)/g, currency, false);

          if (signupMoney && signupMoney[0]) {
            return signupMoney[0]
          }

          //Freespins
          signupFreeSpins = model.getMarkedCampaign(/(s-)+(\d{5,10})*(-\d{5,10})/g, campaigns);
          signupFreeSpins = model.makePromoFreeSpinCampaigns(signupFreeSpins, /(s-|a-)+(\d{5,10})*(-\d{5,10})/g, false);

          if (signupFreeSpins && signupFreeSpins[0]) {
            return signupFreeSpins[0]
          }

          return null;
        }

      });

    };

    model.signupCampaign = function () {
      return model.getCampaigns(true).then(function (campaigns) {
        return model.getPromoGameCampaigns(campaigns);
      });
    };

    model.getMarkedCampaign = function (marker, campaigns, type) {
      if (!campaigns) {
        return null;
      }

      return campaigns.filter(function (campaign) {
          var isMarked = campaign.title.match(marker);
          if (isMarked) {
            campaign.title.replace(marker, '');
          }
          return isMarked;
        }); //[0] || null;
    };
  });
})();
