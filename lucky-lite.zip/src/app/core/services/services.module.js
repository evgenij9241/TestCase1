(function() {
  'use strict';

  angular.module('finnplay.core.services', [
    'finnplay.core.services.md5',
    'finnplay.core.services.payandplay',
    'finnplay.core.services.jackpot',
    'finnplay.core.services.tools',
    'finnplay.core.services.email',
    'finnplay.core.services.landing',
    'finnplay.core.services.ajax',
    'finnplay.core.services.error',
    'finnplay.core.services.notifier',
    'finnplay.core.services.functions',
    'finnplay.core.services.auth',
    'finnplay.core.services.register',
    'finnplay.core.services.payment',
    'finnplay.core.services.profile',
    'finnplay.core.services.limit',
    'finnplay.core.services.transaction',
    'finnplay.core.services.password-resetter',
    'finnplay.core.services.http-interceptor'
  ]);
})();
