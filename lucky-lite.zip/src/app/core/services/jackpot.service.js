(function() {
'use strict';

angular.module('finnplay.core.services.jackpot', [])

.service('Jackpot', function ($rootScope, $q, $state, $timeout, $ajax, $cookies, $filter, Const, Currency, CacheFactory, User) {
  var model = this,
      jackpotList;

  var URLS = {
    jackpots: '/billfold-api/jackpots'
  };

  model.get = function (update) {
    if (!update && jackpotList) {
      return $q.when(jackpotList);
    }
    return User.isLoggedIn(true).then(function (isLoggedIn) {
      var currency = null;
      if (isLoggedIn) {
        return User.getBalance().then(function (balance) {
          currency = balance.currency;
          return model.getJackpots(currency);
        });
      }
      return User.getCountry().then(function (country) {
        currency = 'USD'
        if (Const.countryCurrencies.hasOwnProperty(country)) {
          currency = Const.countryCurrencies[country];
        }
        return model.getJackpots(currency)
      });
    });
  }

  model.getJackpots = function (currency) {
    if (jackpotList) {
      return $q.when(jackpotList);
    }

    return $ajax({
      method: 'GET',
      url: URLS.jackpots + '?currency=' + currency,
      filter: function (response) {
        jackpotList = [];

        if (!response.hasOwnProperty('error')) {
          jackpotList = response;
        }

        return jackpotList;
      }
    });
  }

  model.getGameJackpot = function (gameId) {
    return model.get().then(function (jackpots) {
      var result =  jackpots.filter(function (jackpot) {
        return jackpot.gameId === gameId;
      })[0];

      if (result) {
        result.amountString = $filter('currency')(result.amount, Currency.getSymbol(result.currency));
      }

      return result;
    });
  }

});
})();
