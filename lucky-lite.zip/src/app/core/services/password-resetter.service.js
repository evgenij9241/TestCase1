(function() {
'use strict';

angular.module('finnplay.core.services.password-resetter', [])

.service('PasswordResetter', function ($ajax) {
  var model = this;

  var URLS = {
    forgot: '/billfold-api/player/triggerForgotPassword',
    reset: '/billfold-api/player/modifyForgotPassword'
  };

  // POST: "email", "birthDate"
  model.forgot = function (params) {
    return $ajax({
      method: 'POST',
      url: URLS.forgot,
      data: params
    });
  };

  // POST: "password", "confirmPassword"
  model.reset = function (params) {
    return $ajax({
      method: 'POST',
      url: URLS.reset,
      data: params
    });
  };

});
})();
