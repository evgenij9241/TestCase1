(function() {
  'use strict';

  angular.module('finnplay.core.services.limit', [])
    .service('Limit', function($q, $ajax, fpModal){
      var model = this,
        limits = {};

      var URLS = {
        limits: '/billfold-api/player/limits',
        exclude: '/billfold-api/player/limit/exclude',
        withdrawal: '/billfold-api/player/limit/autoFlush',
        deposit: '/billfold-api/player/limit/deposit',
        oneTime: '/billfold-api/player/limit/oneTime',
        loss: '/billfold-api/player/limit/loss',
        wager: '/billfold-api/player/limit/wager',
        time: '/billfold-api/player/limit/time',
        timeRemove: '/billfold-api/player/limit/time/remove',
        gamingTime: '/billfold-api/player/limit/gamingTime',
        reality: '/billfold-api/player/realityCheck/reset'
      };

      var limitTypes = [
        'deposit', 'loss', 'wager', 'oneTime', 'exclude', 'timeLimit', 'gamingTimeLimit', 'autoFlush'
      ];

      function compliteLimits (response) {
        var _limits = {};
        angular.forEach(limitTypes, function (limitType) {
          var limit = response.filter(function (responseLimit) {
            return responseLimit.hasOwnProperty(limitType);
          })[0];
          if (limit) {
            _limits[limitType] = limit;
          }
        });
        return _limits;
      }

      model.setLimit = function (params, limitFunction) {
        return fpModal.open({
          templateUrl: '/app/modals/check-password/check-password.tmpl.html',
          size: 'md'
        }).result.then(function(data){
          if (data && data.hasOwnProperty('password')) {
            params.password = data.password;
          }

          return limitFunction(params);
        });
      };

      model.getLimits = function (update) {
        if (!update && limits) {
          return $q.when(limits);
        }

        return $ajax({
          method: 'GET',
          url: URLS.limits,
          cache: false,
          filter: function (response) {
            if (response.hasOwnProperty('error')) {
              limits = {};
            } else {
              limits = compliteLimits(response);
            }

            return limits;
          }
        });
      };

      model.updateLossLimit = function (params) {
        return $ajax({
          method: 'POST',
          url: URLS.loss,
          data: params,
          cache: false,
          filter: function (response) {
            if (response.hasOwnProperty('error')) {
              return response;
            } else {
              limits = compliteLimits(response);
            }

            return limits;
          }
        });
      };

      model.updateWagerLimit = function (params) {
        return $ajax({
          method: 'POST',
          url: URLS.wager,
          data: params,
          cache: false,
          filter: function (response) {
            if (response.hasOwnProperty('error')) {
              return response;
            } else {
              limits = compliteLimits(response);
            }

            return limits;
          }
        });
      };

      model.updateTimeLimit = function (params) {
        return $ajax({
          method: 'POST',
          url: params.timeLimit ? URLS.timeRemove : URLS.time,
          data: params.timeLimit ? {} : params,
          cache: false,
          filter: function (response) {
            if (response.hasOwnProperty('error')) {
              return response;
            } else {
              limits = compliteLimits(response);
            }

            return limits;
          }
        });
      };

      model.updateExcludeLimit = function (params) {
        return $ajax({
          method: 'POST',
          url: URLS.exclude,
          data: params,
          cache: false,
          filter: function (response) {
            if (response.hasOwnProperty('error')) {
              return response;
            } else {
              limits = compliteLimits(response);
            }

            return limits;
          }
        });
      };

      model.updateDepositLimit = function (params) {
        return $ajax({
          method: 'POST',
          url: URLS.deposit,
          data: params,
          cache: false,
          filter: function (response) {
            if (response.hasOwnProperty('error')) {
              return response;
            } else {
              limits = compliteLimits(response);
            }

            return limits;
          }
        });
      };

      model.updateOneTimeDepositLimit = function (params) {
        return $ajax({
          method: 'POST',
          url: URLS.oneTime,
          data: params,
          cache: false,
          filter: function (response) {
            if (response.hasOwnProperty('error')) {
              return response;
            } else {
              limits = compliteLimits(response);
            }

            return limits;
          }
        });
      };

      model.updateWithdrawalLimit = function (params) {
        return $ajax({
          method: 'POST',
          url: URLS.withdrawal,
          data: params,
          cache: false,
          filter: function (response) {
            if (response.hasOwnProperty('error')) {
              return response;
            } else {
              limits = compliteLimits(response);
            }

            return limits;
          }
        });
      };

      model.resetRealityCheck = function (answer) {
        return $ajax({
          method: 'GET',
          url: URLS.reality,
          cache: false,
          filter: function (response) {
            return response;
          }
        });
      };
    });

})();
