(function() {
  'use strict';


  angular.module('finnplay.core.services.landing', [])
    .service('Landing', function($cookies, $rootScope, Fn) {
      var model = this;
      var landingQueries = [
        'landing',        //Required query to enable landing on home page. You'll start with blank page by default

        //HEADER
        'header',         //Enable header (Only logo by default)
        'leftNav',        //Enable left nav (header required)
        'rightNav',       //Enable right nav (header required)
        'langSelector',   //Enable language selector (header required)

        //HOME
        'hero',           //Enable Hero pane
        'world',          //Enable deposit switch
        'games',          //Enable featured games list
        'gamesMore',      //Enable more games links
        'gamesDemo',      //Enable demo option
        'gamesRows',      //Limit number of rows in games list (gamesRows=4)
        'animation',      //Enable animation
        'signupTop',      //Enable top signup form
        'signupBottom',   //Enable bottom signup form
        'signupOverlay',  //Enable signup forms overlay on animation (animation & signup(Top/Bottom) required)
        'signupModal',    //Open signup modal window

        //HOME PNP ADDONS
        'deposit',        //Enable deposit as button|modal|form
        'depositAmount',  //Deposit amount 1 - 4 (1 - $10, 2 - $50, 3 - $100, 4 - $500)
        'legacyLogin',    //Show legacy login for pnp with

        //FOOTER
        'footer',         //Enable footer
        'footerLinks',    //Footer links (footer required)
        'footerIcons',    //Footer providers icons (footer required)
        'footerText',     //License footer text (footer required)
      ];

      model.get = function (callback) {
        var url = window.location.href;
        var isLandingQuery = Fn.getUrlParam(url, 'landing');
        var isLandingCookie = $cookies.get('landing');

        if (isLandingQuery) {
          return model.setLandingCookies(url, callback)
        } else if (isLandingCookie) {
          return model.getLandingCookies(callback);
        }

        return callback({})
      }

      model.getLandingCookies = function (callback) {
        var queries = {}
        landingQueries.forEach(function (key) {
          var value = $cookies.get(key);
          if (key === 'gamesRows') {
            value = value ? parseInt(value) :  null;
          }
          queries[key] = value;
        });
        if (callback) {
          callback(queries);
        }
      };

      model.setLandingCookies = function (url, callback) {
        var queries = {}
        landingQueries.forEach(function (key) {
          var value = Fn.getUrlParam(url, key);
          if (value) {
            if (key === 'gamesRows') {
              value = value ? parseInt(value) * 4 : null;
            }
            if (key === 'depositAmount') {
              value = value ? parseInt(value) : null;
            }
            $cookies.put(key, value, { path: '/' });
          } else {
            $cookies.remove(key, { path: '/' });
          }
          queries[key] = value;
        });
        if (callback) {
          callback(queries);
        }
      };

      model.clearLandingCookies = function () {
        $rootScope.landingOptions = {};
        landingQueries.forEach(function (key) {
          $cookies.remove(key);
        });
      };

    });

})();
