(function() {
  'use strict';

  angular.module('finnplay.core.services.payment', [
  ])

  .service('Payment', function($q, $ajax, $state, $window, $rootScope, Deposit, Withdrawal, User, fpModal){
    var model = this,
        currentDeposit,
        currentWithdrawal;

    var SWIFT_VOUCHER_METHOD_ID = 190001; //icheck
    var BANK_ACCOUNTS_METHOD_ID = 1022;


    model.getMethodTitle = function (id) {
      return 'EXT.PAYMENT.METHOD.' + id;
    };

    model.getProviderTitle = function (id) {
      return 'EXT.PAYMENT.PROVIDER.' + id;
    };

    model.getCurrentDeposit = function () {
      return currentDeposit;
    };

    model.setCurrentDeposit = function (params) {
      currentDeposit = params;
    };

    model.getCurrentWithdrawal = function () {
      return currentWithdrawal;
    };

    model.setCurrentWithdrawal = function (params) {
      currentWithdrawal = params;
    };

    model.getDepositDetails = function (update) {
      return Deposit.getDetails(update).then(function(details) {
        if (details.errorCode === 125 && !$rootScope.isPayAndPlay) {
          $state.go('deposit-prefilling');
          return;
        } else {
          return details;
        }
      });
    };

    model.updateDepositPrefillingData = function (params) {
      return Deposit.updatePrefillingData(params).then(function(response) {
        if (response.hasOwnProperty('success')) {
          return User.getDetails(true).then(function () {
            $state.go('deposit');
            return response;
          });
        }
        return response;
      });
    };

    model.deposit = function (params, preventRedirect) {
      return Deposit.deposit(params).then(function(response){
        if (response.hasOwnProperty('success')) {
          if (preventRedirect) {
            return response;
          }
          User.cleanFreeSpins();
          model.redirectToProvider(response);
        }
        return response;
      });
    };

    model.getWithdrawalDetails = function (update) {
      return Withdrawal.getDetails(update).then(function (details) {
        if (details.errorCode === 125 && !$rootScope.isPayAndPlay) {
          $state.go('withdrawal-prefilling');
          return;
        } else {
          return details;
        }
      });
    };

    model.updateWithdrawalPrefillingData = function (params) {
      return Withdrawal.updatePrefillingData(params).then(function (response) {
        if (response.hasOwnProperty('success')) {
          return User.getDetails(true).then(function () {
            $state.go('withdrawal');
            return response;
          });
        }
        return response;
      });
    };

    // POST: amount, method, <user details> ...
    model.withdraw = function (params, payandplay) {
      return Withdrawal.withdraw(params).then(function (response) {
        if (response.hasOwnProperty('success')) {
          if (response.hasOwnProperty('redirectUrl') && !payandplay) {
            response.formMethod = 'REDIRECT';
            model.redirectToProvider(response);
          }

          // Update deposit details because it returns pending withdrawals info
          return $q.all([User.getWallet(true), model.getDepositDetails(true)]).then(function () {
            return response;
          });
        }
        return response;
      });
    };


    // Parse a deposit response data and redirect to the provider's site
    model.redirectToProvider = function (data) {
      var url = data.redirectUrl || '',
          formTarget = data.formTarget || '_top',
          formMethod = data.formMethod || '',
          formParams = data.params || [];

      if (formMethod === 'REDIRECT') {
        $window.location.href = url;
        return true;
      }

      if (formMethod === 'GET' || formMethod === 'POST') {
        var form = document.createElement('form');
        form.setAttribute('target', formTarget);
        form.setAttribute('action', url);
        form.setAttribute('method', formMethod);

        for (var i = 0; i < formParams.length; i++) {
          var name = formParams[i].name,
              value = formParams[i].value,
              hiddenField = document.createElement('input');

          if (name === 'amount') {
            value = parseFloat(value).toFixed(2);
          }

          hiddenField.setAttribute('type', 'hidden');
          hiddenField.setAttribute('name', name);
          hiddenField.setAttribute('value', value);
          form.appendChild(hiddenField);
        }

        document.body.appendChild(form);
        form.submit();
        return true;
      }

      return false;
    };

    model.arePaymentDetailsChanged = function(fields, userDetails, methodData) {
      if (!fields || fields.length === 0) {
        return false;
      }

      for (var i = 0, len = fields.length; i < len; i++) {
        if (fields[i].editable) {
          var fieldName = fields[i].field;

          if (userDetails[fieldName] !== methodData[fieldName]) {
            return true;
          }
        }
      }

      return false;
    };

    model.updatePaymentDetails = function (params) {
      return fpModal.open({
        templateUrl: '/app/modals/check-password/check-password.tmpl.html',
        size: 'md'
      }).result.then(function(data){
        if (data && data.hasOwnProperty('password')) {
          params.password = data.password;
        }
        return User.updatePaymentDetails(params);
      });
    };

    model.calculateFee = function (amount, fixedFee, percentageFee) {
      var fee = 0;

      if (fixedFee > 0) {
        fee = fixedFee;
      }

      if (percentageFee > 0) {
        fee = Math.round((amount * percentageFee / 100 + fee) * 100) / 100;
      }

      return fee;
    };

    // Is user used creadit card previously - lastUsedMethon on deposit is swiftvoucher or has visa token
    model.hasCreditCard = function () {
      return model.getDepositDetails().then(function(d){
        if (SWIFT_VOUCHER_METHOD_ID === d.lastDepositMethod) {
          return true;
        } else {
          return model.getWithdrawalDetails().then(function(d){
            var methods = d ? d.methods || [] : [];

            var hasCreditCard = false;
            angular.forEach(methods, function(method) {
              if (BANK_ACCOUNTS_METHOD_ID === method.method && method.stored && angular.isArray(method.storedData)) {
                hasCreditCard = true;
              }
            });

            return hasCreditCard;
          });
        }
      });
    };

    var CARD = {
      Maestro: {
        REGEXP: /^5010|5011|5012|5013|5014|5015|5016|5017|5018|502|503|504|505|506|508|56|58|6012|6013|6014|6015|6016|6017|6018|6019|602|603|604|605|6060|670|671|672|673|674|675|677|676/,
        min: 12,
        max: 12
      },
      MasterCard: {
        REGEXP: /^51|52|53|54|55/,
        min: 12,
        max: 12
      },
      VisaElectron: {
        REGEXP: /^4026|417500|4405|4508|4844|4913|4917/,
        min: 12,
        max: 12
      },
      Visa: {
        REGEXP: /^4/,
        min: 12,
        max: 12
      }
    };

    model.cardType = function (cardNumber) {
      if (CARD.Maestro.REGEXP.test(cardNumber)) {
        return 'Maestro';
      }
      if (CARD.MasterCard.REGEXP.test(cardNumber)) {
        return 'MasterCard';
      }
      if (CARD.VisaElectron.REGEXP.test(cardNumber)) {
        return 'VisaElectron'
      }
      if (CARD.Visa.REGEXP.test(cardNumber)) {
        return 'Visa';
      }
      return null;
    };

    model.isCardValid = function (cardNumber) {
      if (!cardNumber) return false;
      var cardLength = (cardNumber + '').length;
      var cardType = model.cardType(cardNumber);

      if (cardType && CARD[cardType].min >= cardLength && CARD[cardType].min <= cardLength) {
        return true;
      }

      return false;
    }

  });

})();
