(function() {
  'use strict';

  angular.module('finnplay.core.services.profile', [])
    .service('Profile', function(User, fpModal){
      var model = this;

      model.updatePassword = function (params) {
        return fpModal.open({
          templateUrl: '/app/modals/check-birthdate/check-birthdate.tmpl.html',
          size: 'md'
        }).result.then(function(data){
          if (data && data.hasOwnProperty('birthdate')) {
            var birthdate = data.birthdate.split('-');
            if (birthdate.length < 3) {
              return;
            }
            params['year-birthDate'] = birthdate[0];
            params['month-birthDate'] = birthdate[1];
            params['day-birthDate'] = birthdate[2];

            return User.updatePassword(params);
          }
        });
      };
    });

})();
