(function() {
'use strict';

angular.module('finnplay.core.services.payandplay', [])

  .service('PayAndPlay', function () {
    var model = this;
    var PNP_COUNTRIES = ['SWE', 'FIN']

    model.isPayAndPlayCountry = function () {
      return new Promise(function (resolve) {
        return resolve(true /* true - is PnP country, false - in not PnP country*/);
      });
    };

  });
})();
