(function() {
    'use strict';

    angular.module('finnplay.core.services.transaction', [])
        .service('Transaction', function($q, $ajax){
            var model = this;

            var URLS = {
                games: '/billfold-api/transactions/games',
                loyalty: '/billfold-api/transactions/loyalty',
                withdrawals: '/billfold-api/transactions/withdrawals',
                deposits: '/billfold-api/transactions/deposits',
                purchases: '/billfold-api/transactions/purchases',
                promo: '/billfold-api/transactions/promo'
            };

            model.getGames = function (params) {
                return $ajax({
                    method: 'GET',
                    url: URLS.games,
                    params: params,
                    cache: false
                });
            };

            model.getPromo = function (params) {
                return $ajax({
                    method: 'GET',
                    url: URLS.promo,
                    params: params,
                    cache: false
                });
            };

            model.getDeposit = function (params) {
                return $ajax({
                    method: 'GET',
                    url: URLS.deposits,
                    params: params,
                    cache: false
                });
            };

            model.getWithdrawal = function (params) {
                return $ajax({
                    method: 'GET',
                    url: URLS.withdrawals,
                    params: params,
                    cache: false
                });
            };

            model.getLoyalty = function (params) {
                return $ajax({
                    method: 'GET',
                    url: URLS.loyalty,
                    params: params,
                    cache: false
                });
            };

            model.getBetting = function (params) {
                return $ajax({
                    method: 'GET',
                    url: URLS.purchases,
                    params: params,
                    cache: false
                });
            };
        });

})();