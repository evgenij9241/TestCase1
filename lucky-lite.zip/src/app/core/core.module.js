(function() {
  'use strict';

  angular.module('finnplay.core', [
    'finnplay.models.language',
    'finnplay.models.user',
    'finnplay.models.game',
    'finnplay.models.deposit',
    'finnplay.models.withdrawal',
    'finnplay.models.currency',
    'finnplay.models.campaign',
    'finnplay.models.betinaction',
    'finnplay.core.services',
    'finnplay.core.filters',
    'finnplay.core.validators',
    'finnplay.core.common',
    'finnplay.core.decorators.state',
  ]);
})();
