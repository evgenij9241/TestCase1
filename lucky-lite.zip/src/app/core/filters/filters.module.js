(function() {
  'use strict';

  angular.module('finnplay.core.filters', []);
})();