(function() {
  'use strict';

  angular.module('finnplay.core.common', [
    'finnplay.core.common.logout'
  ]);
})();