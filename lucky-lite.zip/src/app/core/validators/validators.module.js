(function() {
  'use strict';

  angular.module('finnplay.core.validators', [
    'finnplay.core.validators'
  ]);
})();