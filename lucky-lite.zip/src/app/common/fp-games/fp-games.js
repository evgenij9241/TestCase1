(function() {
  'use strict';

  angular.module('finnplay.common.games', [
    'finnplay.common.game.list',
    'finnplay.common.game.featured'
  ]);
})();
