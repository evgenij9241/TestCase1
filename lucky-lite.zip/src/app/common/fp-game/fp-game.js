(function() {
  'use strict';

  angular.module('finnplay.common.game', [
    'finnplay.common.game.mobile',
    'finnplay.common.game.thumbnail',
    'finnplay.common.game.thumbnail-search'
  ]);
})();
