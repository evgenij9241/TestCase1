(function() {
    'use strict';

    angular.module('finnplay.common.buttons', [
        'finnplay.common.buttons.radio',
        'finnplay.common.buttons.checkbox'
    ]);
})();