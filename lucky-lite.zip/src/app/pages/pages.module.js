(function() {
  'use strict';

  angular.module('finnplay.pages', [
    'finnplay.pages.home'
  ]);
})();
