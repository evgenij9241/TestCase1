(function() {
  'use strict';

  angular.module('finnplay.modals', []);
})();
