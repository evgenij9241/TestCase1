(function() {
  'use strict';

  angular
    .module('finnplay')
    .constant('moment', window.moment)
    .constant('is', window.is);

})();
